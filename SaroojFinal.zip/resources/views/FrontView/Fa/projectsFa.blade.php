@extends("layouts.frontFaMaster")
@section("contentFrontFa")
    @include("FrontView.partials.Fa.projects")
@endsection

