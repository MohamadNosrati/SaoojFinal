@extends("layouts.frontEnMaster")
@section("titleEn","sarooj projects")
@section("contentEn")
@include("FrontView.partials.En.projectsEn")
@endsection


