<div class="category">
    <h1 class="">دسته بندی</h1>
    <div class="itemCategories">
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->publish===1): ?>
                <div>
                    <a href="<?php echo e(route("projects.category",["category"=>$item->nameFa])); ?>"></a>
                    <img src="<?php echo e(asset("images/category/".$item->image)); ?>" alt="">
                    <div class="cover">
                        <a href="<?php echo e(route("projects.category",["category"=>$item->nameFa])); ?>"><?php echo e($item->nameFa); ?></a>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/partials/Fa/category.blade.php ENDPATH**/ ?>