<?php $__env->startSection("titleEn","sarooj projects"); ?>
<?php $__env->startSection("contentEn"); ?>
<?php echo $__env->make("FrontView.partials.En.projectsEn", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("layouts.frontEnMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/En/projectsEn.blade.php ENDPATH**/ ?>