<!-- ***** start top Pic ***** -->
<div class="picture">
    <img src="<?php echo e(asset("images/general/".$general->projectsImage)); ?>" alt="<?php echo e($general->altProjectsImageEn); ?>">
    <h1>projects</h1>
</div>
<!-- ***** End top Pic ***** -->
<!-- ***** start projects ***** -->
<div class="projects projectsLightBg dark:projectsDarkBg">
    <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item->publish===1): ?>
            <div class="project">
                <a href="<?php echo e(route("projectInfoEn",["projectName"=>$item->PNameEn])); ?>"></a>
                <img src="<?php echo e(asset("images/project/".$item->image)); ?>" alt="<?php echo e($item->altEn); ?>">
                <div class="cover">
                    <a href="<?php echo e(route("projectInfoEn",["projectName"=>$item->PNameEn])); ?>"><?php echo e($item->PNameEn); ?></a>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($project->links()); ?>

</div>
<!-- ***** End projects ***** -->
<?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/partials/En/projectsEn.blade.php ENDPATH**/ ?>