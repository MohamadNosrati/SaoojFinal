<?php if($paginator->hasPages()): ?>
    <div dir="ltr" class="mainPagination">
        <ul class="">
            <?php if($paginator->onFirstPage()): ?>
                <li class="direction daPaginate" aria-disabled="true">
                    <span class="page-link bg-dark text-white rounded-0" aria-hidden="true">&lsaquo;</span>
                </li>
            <?php else: ?>
                <li class="direction">
                    <a class="page-link text-white bg-dark rounded-0" href="<?php echo e($paginator->previousPageUrl()); ?>"
                       rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">&lsaquo;</a>
                </li>
            <?php endif; ?>
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(is_string($element)): ?>
                    <li class="number disabled" aria-disabled="true"><span
                            class="page-link"><?php echo e($element); ?></span></li>
                <?php endif; ?>
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li  class="number activePage" aria-current="page"><span
                                    class="page-link"><?php echo e($page); ?></span></li>
                        <?php else: ?>
                            <li  class="number"><a class="page-link"
                                                                href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($paginator->hasMorePages()): ?>
                <li class="direction">
                    <a class="page-link text-white bg-dark rounded-0" href="<?php echo e($paginator->nextPageUrl()); ?>"
                       rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">&rsaquo;</a>
                </li>
            <?php else: ?>
                <li class="direction daPaginate" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                    <span class="page-link text-white bg-dark rounded-0" aria-hidden="true">&rsaquo;</span>
                </li>
            <?php endif; ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH D:\web design\projects\Sarooj\SaroojFinal\resources\views/vendor/pagination/bootstrap-5.blade.php ENDPATH**/ ?>