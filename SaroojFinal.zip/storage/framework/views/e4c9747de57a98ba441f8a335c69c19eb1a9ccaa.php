<div class="lastProjects lpLightBg dark:lpDarkBg">
    <h1 class="dark:text-[#D6D6D6]">آخرین پروژه ها</h1>
    <div class="lpItems">
        <?php $__currentLoopData = $lp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <a href="<?php echo e(route("projectInfo",["projectName"=>$item->PNameFa])); ?>"></a>
                <img src="<?php echo e(asset("images/project/".$item->image)); ?>" alt="<?php echo e($item->altFa); ?>">
                <div class="cover">
                    <a href="<?php echo e(route("projectInfo",["projectName"=>$item->PNameFa])); ?>"><?php echo e($item->PNameFa); ?></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\web design\projects\Sarooj\SaroojFinal\resources\views/FrontView/partials/fa/lp.blade.php ENDPATH**/ ?>