<?php $__env->startSection("titleFa","جزییات"); ?>
<?php $__env->startSection("contentFrontFa"); ?>
    <!-- ***** Start Details ***** -->
    <div class="details bfLightBg dark:bfDarkBg">
    <h1 class="text-[black] dark:text-[#F1F1F2]">جزییات پروژه</h1>
    <!-- ***** Start BF ***** -->
    <?php echo $__env->make("FrontView.partials.bf", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End BF ***** -->
    <!-- ***** start projectInfo ***** --->
    <?php echo $__env->make("FrontView.partials.fa.info", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End projectInfo --->
    <!-- ***** End Details ***** -->
    <!-- ***** start video ***** -->
    <?php echo $__env->make("FrontView.partials.video", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End video ***** -->
    <!-- ***** start Last Projects ***** -->
    <?php echo $__env->make("FrontView.partials.fa.lp", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End last Projects ***** -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make("layouts.frontFaMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/fa/detailsFa.blade.php ENDPATH**/ ?>