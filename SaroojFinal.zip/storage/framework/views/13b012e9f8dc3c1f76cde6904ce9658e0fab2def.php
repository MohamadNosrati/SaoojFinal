<div class="location">
    <iframe src="https://nshn.ir/78_bvhxHWxOPHz"></iframe>
</div>
<?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/partials/location.blade.php ENDPATH**/ ?>