<?php $__env->startSection("titleBack","Sarooj Edit"); ?>
<?php $__env->startSection("contentBack"); ?>
    <div class="col-12 my-5">
        <h1 class="text-white text-center text-capitalize mb-3">sarooj Edit</h1>
        <div class="col-8 mx-auto my-4 bg-dark py-4 px-5 rounded-4">
            <?php echo Form::model($sarooj,["route"=>["sarooj.update","id"=>$sarooj->id],"method"=>"put","files"=>true]); ?>

            <div class="text-center">
                <img style="width: 125px;height: 125px;border-radius: 50%;object-fit: cover" src="<?php echo e(asset("images/sarooj/".$sarooj->logo)); ?>">
            </div>
            <?php echo Form::label("logo","logo",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::file("logo",["class"=>"form-control mb-3 text-capitalize"]); ?>

            <?php $__errorArgs = ["logo"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altLogoFa","altLogoFa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altLogoFa",old("altLogoFa"),["class"=>"form-control mb-3 persian","placeholder"=>"Enter Your Persian alt Logo"]); ?>

            <?php $__errorArgs = ["altLogoFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altLogoEn","altLogoEn",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altLogoEn",old("altLogoEn"),["class"=>"form-control mb-3","placeholder"=>"Enter Your English alt Logo"]); ?>

            <?php $__errorArgs = ["altLogoEn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("email","email",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("email",old("email"),["class"=>"form-control mb-3","placeholder"=>"Enter Your Persian email"]); ?>

            <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("phone1","phone1",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("phone1",old("phone1"),["class"=>"form-control mb-3","placeholder"=>"Enter Your Persian phone1"]); ?>

            <?php $__errorArgs = ["phone1"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("phone2","phone2",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("phone2",old("phone2"),["class"=>"form-control mb-3","placeholder"=>"Enter Your Persian phone2"]); ?>

            <?php $__errorArgs = ["phone2"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("telegram","telegram",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::textarea("telegram",old("telegram"),["class"=>"form-control mb-3","placeholder"=>"Enter Your telegram"]); ?>

            <?php $__errorArgs = ["telegram"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("instagram","instagram",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::textarea("instagram",old("instagram"),["class"=>"form-control mb-3","placeholder"=>"Enter Your instagram"]); ?>

            <?php $__errorArgs = ["instagram"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("linkin","linkin",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::textarea("linkin",old("linkin"),["class"=>"form-control mb-3","placeholder"=>"Enter Your linkin"]); ?>

            <?php $__errorArgs = ["linkin"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("addressFa","addressFa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("addressFa",old("addressFa"),["class"=>"form-control mb-3 persian","placeholder"=>"Enter Your Persian address"]); ?>

            <?php $__errorArgs = ["addressFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("addressEn","addressEn",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("addressEn",old("addressEn"),["class"=>"form-control mb-3","placeholder"=>"Enter Your English Address"]); ?>

            <?php $__errorArgs = ["addressEn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("blogFa","blogFa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::textarea("blogFa",old("blogFa"),["class"=>"form-control mb-3 persian","placeholder"=>"Enter Your Persian Name"]); ?>

            <?php $__errorArgs = ["blogFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("blogEn","blogEn",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::textarea("blogEn",old("blogEn"),["class"=>"form-control mb-3","placeholder"=>"Enter Your English blog"]); ?>

            <?php $__errorArgs = ["blogEn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::submit("edit",["class"=>"text-capitalize text-white btn btn-warning"]); ?>

            <?php echo Form::close(""); ?>

        </div>
        <?php if(session()->exists("create")): ?>
            <div class="session my-4 bg-success py-3 px-2 col-4 mx-auto rounded-3">
                <h3 class="text-center text-capitalize text-white">your record created successfully!</h3>
            </div>
        <?php endif; ?>
        <div class="text-center">
            <a class="btn btn-info text-white text-capitalize mt-3" href="<?php echo e(route("sarooj.index")); ?>">details sarooj</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/backView/sarooj/edit.blade.php ENDPATH**/ ?>