<div class="blog">
    <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="blogPic">
            <img src="<?php echo e(asset("images/blog/".$item->image)); ?>" alt="<?php echo e($item->altEn); ?>">
        </div>
        <div class="blogText">
            <h1>About<span> Us</span></h1>
            <p>
                <?php echo e($item->textEn); ?>

            </p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/partials/En/blogEn.blade.php ENDPATH**/ ?>