<?php $__env->startSection("contentEn"); ?>
    <!-- ***** start Details ***** -->
    <div class="details bfLightBg dark:bfDarkBg">
        <h1 class="text-[black] dark:text-[#F1F1F2]"><?php echo e($project->PNameEn); ?> Project</h1>
        <!-- ***** Start BF ***** -->
    <?php echo $__env->make("FrontView.partials.En.bf", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End BF ***** -->
        <!-- ***** start info ***** -->
    <?php echo $__env->make("FrontView.partials.En.infoEn", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ******* start video ***** -->
    <?php echo $__env->make("FrontView.partials.video", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ******* End video ***** -->
    </div>
    <!-- ***** End Details ***** -->
    <!-- ***** start Last Projects ***** -->
    <?php echo $__env->make("FrontView.partials.En.lpEn", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End last Projects ***** -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
    <script src="<?php echo e(asset("Front Assets/swiper/swiper-bundle.min.js")); ?>"></script>
    <script src="<?php echo e(asset("Front Assets/js/Bf.js")); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.frontEnMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/En/detailsEn.blade.php ENDPATH**/ ?>