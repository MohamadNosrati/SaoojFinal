<?php $__env->startSection("titleBack","Sarooj Admin panel"); ?>
<?php $__env->startSection("contentBack"); ?>
    <h1>welcome to your admin panel <?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?></h1>
    <div class="panelItems">
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("slider.index")); ?>">slider info</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("service.index")); ?>">service info</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("faq.index")); ?>">faq info</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("category.index")); ?>">category info</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("team.index")); ?>">team info</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("project.index")); ?>">project info</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("info.index")); ?>">project details</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("seo.index")); ?>">seo info</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("sarooj.index")); ?>">sarooj info</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("comment.index")); ?>">persian comments</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("blog.index")); ?>">blog info</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("bf.index")); ?>">project image</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("social.index")); ?>">team socials</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("general.index")); ?>">general images</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("commentEn.index")); ?>">English comments</a>
        </div>
        <div class="text-center bg-dark">
            <img src="<?php echo e(asset("images/logo/logoUsual.jpg")); ?>">
            <a class="btn text-white my-3 text-capitalize" href="<?php echo e(route("seoEn.index")); ?>">English Seo</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("layouts.backMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/backView/panel/index.blade.php ENDPATH**/ ?>