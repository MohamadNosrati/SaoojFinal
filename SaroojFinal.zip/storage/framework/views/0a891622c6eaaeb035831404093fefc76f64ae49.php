<?php $__env->startSection("titleBack","Info Edit"); ?>
<?php $__env->startSection("contentBack"); ?>
    <div class="col-12 my-5">
        <h1 class="text-white text-center text-capitalize mb-3">info Edit</h1>
        <div class="col-8 mx-auto my-4 bg-dark py-4 px-5 rounded-4">
            <?php echo Form::model($info,["route"=>["info.update","id"=>$info->id],"method"=>"put","files"=>true]); ?>

            <?php echo Form::label("videoId","videoId",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::number("videoId",$info->video_id,["class"=>"form-control mb-3 text-capitalize","placeholder"=>"Please Enter Your Video Id"]); ?>

            <?php $__errorArgs = ["videoId"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("video","video",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("video",old("video"),["class"=>"form-control mb-3 text-capitalize","placeholder"=>"Please Enter Your Video Source"]); ?>

            <?php $__errorArgs = ["video"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("area","area",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::number("area",old("area"),["class"=>"form-control mb-3 text-capitalize","min"=>0,"placeholder"=>"Please Enter Your Area"]); ?>

            <?php $__errorArgs = ["area"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("startFa","startFa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("startFa",old("startFa"),["class"=>"form-control mb-3 persian","id"=>"startFa","placeholder"=>"Please Enter Your Start Persian Date"]); ?>

            <?php $__errorArgs = ["startFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("endFa","endFa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("endFa",old("endFa"),["class"=>"form-control mb-3 persian","id"=>"endFa","placeholder"=>"Please Enter Your End Persian Date"]); ?>

            <?php $__errorArgs = ["endFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("textFa","textFa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::textarea("textFa",old("textFa"),["class"=>"form-control mb-3 persian","placeholder"=>"Please Enter Your textFa"]); ?>

            <?php $__errorArgs = ["textFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("textEn","textEn",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::textarea("textEn",old("textEn"),["class"=>"form-control mb-3","placeholder"=>"Please Enter Your Text En"]); ?>

            <?php $__errorArgs = ["textEn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("project_id","project",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::select("project_id",$project,$info->id,["class"=>"form-select mb-3"]); ?>

            <?php $__errorArgs = ["project_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::submit("Edit",["class"=>"text-capitalize text-white btn btn-warning"]); ?>

            <?php echo Form::close(); ?>

        </div>
        <div class="text-center">
            <a class="btn btn-info text-white text-capitalize mt-3" href="<?php echo e(route("info.index")); ?>">details info</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
    <script src="<?php echo e(asset("jquery/dist/jquery.min.js")); ?>"></script>
    <script src="<?php echo e(asset("Persian_Calendar/src/kamadatepicker.js")); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/backView/info/edit.blade.php ENDPATH**/ ?>