<div class="swiper mySwiperSlider">
    <div class="swiper-wrapper">
        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->publish===1): ?>
                <div class="swiper-slide">
                    <img src="<?php echo e(asset("images/slider/".$item->image)); ?>" alt="<?php echo e($item->altFa); ?>">
                    <div class="text">
                        <h1 class=""><?php echo e($item->titleFa); ?></h1>
                        <p class="text-[#1D1D1D]">
                            <?php echo e($item->textFa); ?>

                        </p>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-pagination"></div>
</div>
<?php /**PATH D:\web design\projects\Sarooj\SaroojFinal\resources\views/FrontView/partials/Fa/slider.blade.php ENDPATH**/ ?>