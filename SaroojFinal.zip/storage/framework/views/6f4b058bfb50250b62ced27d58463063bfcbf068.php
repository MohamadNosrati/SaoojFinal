<div class="contact">
    <h2 class="dark:text-[#D6D6D6]">با ما در ارتباط باشید</h2>
    <div class="totalContact">
        <div class="singleContact">
            <img src="<?php echo e(asset("Front Assets/Icons/Contact/email.svg")); ?>" alt="">
            <b>ایمیل</b>
            <span class="dark:text-[#D6D6D6]"><?php echo e($sarooj->email); ?></span>
        </div>
        <div class="singleContact">
            <img src="<?php echo e(asset("Front Assets/Icons/Contact/location.svg")); ?>" alt="">
            <b>آدرس</b>
            <p class="dark:text-[#D6D6D6]">
                <?php echo e($sarooj->addressFa); ?>

            </p>
        </div>
        <div class="singleContact">
            <img src="<?php echo e(asset("Front Assets/Icons/Contact/phone.svg")); ?>" alt="">
            <b>شماره تماس</b>
            <span class="dark:text-[#D6D6D6]"><?php echo e($sarooj->phone1); ?></span>
            <?php if(!empty($sarooj->phone2)): ?>
                <span class="dark:text-[#D6D6D6]"><?php echo e($sarooj->phone2); ?></span>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/partials/Fa/contact.blade.php ENDPATH**/ ?>