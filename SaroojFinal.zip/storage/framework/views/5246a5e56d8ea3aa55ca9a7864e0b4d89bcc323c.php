<?php $__env->startSection("titleBack","Slider Index"); ?>
<?php $__env->startSection("contentBack"); ?>
<div class="col-12 my-5 text-center mx-auto">
    <h1 class="text-white text-center text-capitalize mb-3">slider details</h1>
    <div class="mb-5 bg-white p-3 rounded-3">
        <table class="table table-dark table-responsive text-white rounded-3 px-2 py-4">
            <tr>
                <td class="text-center text-capitalize">id</td>
                <td class="text-center text-capitalize">image</td>
                <td class="text-center text-capitalize">altFa</td>
                <td class="text-center text-capitalize">altEn</td>
                <td class="text-center text-capitalize">titleFa</td>
                <td class="text-center text-capitalize">titleEn</td>
                <td class="text-center text-capitalize">textFa</td>
                <td class="text-center text-capitalize">textEn</td>
                <td class="text-center text-capitalize">createdAt</td>
                <td class="text-center text-capitalize">updatedAt</td>
                <td class="text-center text-capitalize">publish</td>
                <td class="text-center text-capitalize">delete</td>
                <td class="text-center text-capitalize">update</td>
            </tr>
            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="line-height: 120px"><?php echo e($item->id); ?></td>
                    <td style="line-height: 120px">
                        <img style="width:125px;height: 125px;border-radius: 50%;object-fit: cover " src="<?php echo e(asset("images/slider/".$item->image)); ?>">
                    </td>
                    <td style="line-height: 120px"><?php echo e(mb_strcut($item->altFa,0,10)); ?></td>
                    <td style="line-height: 120px"><?php echo e($item->altEn); ?></td>
                    <td style="line-height: 120px"><?php echo e(mb_strcut($item->titleFa,0,10)); ?></td>
                    <td style="line-height: 120px"><?php echo e(substr($item->titleEn,0,20)); ?></td>
                    <td style="line-height: 120px"><?php echo e(mb_strcut($item->textFa,0,20)); ?></td>
                    <td style="line-height: 120px"><?php echo e(substr($item->textEn,0,20)); ?></td>
                    <td style="line-height: 120px"><?php echo e(\Morilog\Jalali\Jalalian::forge("$item->created_at")->addSeconds()); ?></td>
                    <td style="line-height: 120px"><?php echo e(\Morilog\Jalali\Jalalian::forge("$item->updated_at")->addMinutes()); ?></td>
                    <td style="line-height: 120px">
                        <?php if($item->publish===1): ?>
                            <span class="btn btn-outline-success">Active</span>
                        <?php else: ?>
                            <span class="btn btn-outline-danger">DeActive</span>
                        <?php endif; ?>
                    </td>
                    <td style="line-height: 120px">
                        <?php echo Form::open(["route"=>["slider.destroy","id"=>$item->id],"method"=>"delete"]); ?>

                        <?php echo Form::submit("delete",["class"=>"btn btn-danger text-capitalize text-white"]); ?>

                        <?php echo Form::close(); ?>

                    </td>
                    <td style="line-height: 120px">
                        <a class="btn btn-warning text-capitalize text-white" href="<?php echo e(route("slider.edit",["id"=>$item->id])); ?>">update</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <?php if(session()->exists("delete")): ?>
        <div class="session my-4 bg-danger py-3 px-2 col-4 mx-auto rounded-3">
            <h3 class="text-center text-capitalize text-white">your record deleted successfully!</h3>
        </div>
    <?php endif; ?>
    <?php if(session()->exists("update")): ?>
        <div class="session my-4 bg-warning py-3 px-2 col-4 mx-auto rounded-3">
            <h3 class="text-center text-capitalize text-white">your record updated successfully!</h3>
        </div>
    <?php endif; ?>
    <a class="btn btn-success text-white text-capitalize mt-5" href="<?php echo e(route("slider.create")); ?>">create slider</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/backView/slider/index.blade.php ENDPATH**/ ?>