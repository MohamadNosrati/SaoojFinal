<?php $__env->startSection("titleBack","General Edit"); ?>
<?php $__env->startSection("contentBack"); ?>
    <div class="col-12 my-5">
        <h1 class="text-white text-center text-capitalize mb-3">General Edit</h1>
        <div class="col-8 mx-auto my-4 bg-dark py-4 px-5 rounded-4">
            <?php echo Form::model($general,["route"=>["general.update","id"=>$general->id],"method"=>"put","files"=>true]); ?>

            <div class="text-center">
                <img style="width: 125px;height: 125px;border-radius: 50%;object-fit: cover" src="<?php echo e(asset("images/general/".$general->ServiceImage)); ?>">
            </div>
            <div class="text-center">
                <img style="width: 125px;height: 125px;border-radius: 50%;object-fit: cover ;margin: 25px 0" src="<?php echo e(asset("images/general/".$general->projectsImage)); ?>">
            </div>
            <?php echo Form::label("serviceImage","serviceImage",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::file("serviceImage",["class"=>"form-control mb-3 text-capitalize"]); ?>

            <?php $__errorArgs = ["serviceImage"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("projectsImage","projectsImage",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::file("projectsImage",["class"=>"form-control mb-3 text-capitalize"]); ?>

            <?php $__errorArgs = ["projectsImage"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altServiceImageFa","alt ServiceImage Fa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altServiceImageFa",old("altServiceImageFa"),["class"=>"form-control mb-3 text capitalize persian","placeholder"=>"Enter Your Persian Alt serviceImage"]); ?>

            <?php $__errorArgs = ["altServiceImageFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altServiceImageEn","alt ServiceImage En",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altServiceImageEn",old("altServiceImageEn"),["class"=>"form-control mb-3 text capitalize","placeholder"=>"Enter Your English Alt serviceImage"]); ?>

            <?php $__errorArgs = ["altServiceImageEn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altProjectsImageFa","alt ProjectsImage Fa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altProjectsImageFa",old("altProjectsImageFa"),["class"=>"form-control mb-3 text capitalize persian","placeholder"=>"Enter Your Persian Alt ProjectsImage"]); ?>

            <?php $__errorArgs = ["altProjectsImageFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altProjectsImageEn","alt ProjectsImage En",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altProjectsImageEn",old("altProjectsImageEn"),["class"=>"form-control mb-3 text capitalize","placeholder"=>"Enter Your English Alt ProjectsImage"]); ?>

            <?php $__errorArgs = ["altProjectsImageEn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::submit("Edit",["class"=>"text-capitalize text-white btn btn-warning"]); ?>

            <?php echo Form::close(""); ?>

        </div>
        <div class="text-center">
            <a class="btn btn-info text-white text-capitalize mt-3" href="<?php echo e(route("general.index")); ?>">details General</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/backView/general/edit.blade.php ENDPATH**/ ?>