<div class="category">
    <h1 class="">Categories</h1>
    <div class="itemCategories">
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->publish===1): ?>
                <div>
                    <a href="<?php echo e(route("projectsEn.category",["category"=>$item->nameEn])); ?>"></a>
                    <img src="<?php echo e(asset("images/category/".$item->image)); ?>" alt="<?php echo e($item->altEn); ?>">
                    <div class="cover">
                        <a href="<?php echo e(route("projectsEn.category",["category"=>$item->nameEn])); ?>"><?php echo e($item->nameEn); ?></a>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/partials/En/categoryEn.blade.php ENDPATH**/ ?>