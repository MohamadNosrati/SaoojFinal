<div id="faq" class="faq">
    <h1>سوالات متداول</h1>
    <div class="faqItems">
        <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->publish===1): ?>
                <div class="singleFaq">
                    <div class="question">
                        <div class="iconQuestion">
                            <img src="<?php echo e(asset("images/faq/".$item->image)); ?>" alt="<?php echo e($item->altFa); ?>">>
                        </div>
                        <div class="textQuestion">
                            <h4>
                                <?php echo e($item->questionFa); ?>

                            </h4>
                        </div>
                        <div class="iconDirection">
                            <img src="<?php echo e(asset("Front Assets/Icons/FAQ/direction.svg")); ?>" alt="">
                        </div>
                    </div>
                    <div class="answer">
                        <p>
                            <?php echo e($item->answerFa); ?>

                        </p>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/partials/Fa/faq.blade.php ENDPATH**/ ?>