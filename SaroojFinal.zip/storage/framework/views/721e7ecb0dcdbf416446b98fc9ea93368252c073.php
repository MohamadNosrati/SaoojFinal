<?php $__env->startSection("titleBack","Category Edit"); ?>
<?php $__env->startSection("contentBack"); ?>
    <div class="col-12 my-5">
        <h1 class="text-white text-center text-capitalize mb-3">Category create</h1>
        <div class="col-8 mx-auto my-4 bg-dark py-4 px-5 rounded-4">
            <?php echo Form::model($category,["route"=>["category.update","id"=>$category->id],"method"=>"put","files"=>true]); ?>

            <div class="text-center">
                <img style="width: 125px;height: 125px;border-radius: 50%;object-fit: cover" src="<?php echo e(asset("images/category/".$category->image)); ?>" alt="">
            </div>
            <?php echo Form::label("image","image",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::file("image",["class"=>"form-control mb-3 text-capitalize"]); ?>

            <?php $__errorArgs = ["image"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altFa","altFa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altFa",old("altFa"),["class"=>"form-control mb-3 text capitalize persian","placeholder"=>"Enter Your Persian Alt"]); ?>

            <?php $__errorArgs = ["altFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altEn","altEn",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altEn",old("altEn"),["class"=>"form-control mb-3","placeholder"=>"Enter Your English Alt"]); ?>

            <?php $__errorArgs = ["altEn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("nameFa","nameFa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("nameFa",old("nameFa"),["class"=>"form-control mb-3 persian","placeholder"=>"Enter Your Persian Name"]); ?>

            <?php $__errorArgs = ["nameFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("nameEn","nameEn",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("nameEn",old("nameEn"),["class"=>"form-control mb-3","placeholder"=>"Enter Your English name"]); ?>

            <?php $__errorArgs = ["nameEn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("publish","publish",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::select("publish",[1=>"Active",0=>"DeActive"],$category->publish,["class"=>"form-select mb-3"]); ?>

            <?php echo Form::submit("Edit",["class"=>"text-capitalize text-white btn btn-warning"]); ?>

            <?php echo Form::close(""); ?>

        </div>
        <div class="text-center">
            <a class="btn btn-info text-white text-capitalize mt-3" href="<?php echo e(route("category.index")); ?>">details Category</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/backView/category/edit.blade.php ENDPATH**/ ?>