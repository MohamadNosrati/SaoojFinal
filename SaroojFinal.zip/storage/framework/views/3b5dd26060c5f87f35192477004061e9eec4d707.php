<?php $__env->startSection("contentEn"); ?>
    <!-- ***** Start Blog ***** -->
    <?php echo $__env->make("FrontView.partials.En.blogEn", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End Blog ***** -->
    <!-- ***** start Comments ***** -->
    <?php echo $__env->make("FrontView.partials.En.commentsEn", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End Comments ***** -->
    <!-- ***** start contact ***** -->
    <?php echo $__env->make("FrontView.partials.En.contactEn", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End contact  ***** -->
    <!-- ***** start Form ***** -->
    <?php echo $__env->make("FrontView.partials.En.formEn", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End Form ***** -->
    <!-- ***** Start Socials ***** -->
    <?php echo $__env->make("FrontView.partials.En.socialsEn", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End Socials ***** -->
    <!-- ***** start Location ***** -->
    <?php echo $__env->make("FrontView.partials.location", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End Location ***** -->
    <!-- ***** start footer ***** -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
    <script src="<?php echo e(asset("jquery/dist/jquery.min.js")); ?>"></script>
    <script src="<?php echo e(asset("jquery-toast-plugin-master/dist/jquery.toast.min.js")); ?>"></script>
    <script src="<?php echo e(asset("Front Assets/js/FormEn.js")); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("layouts.frontEnMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/En/aboutEn.blade.php ENDPATH**/ ?>