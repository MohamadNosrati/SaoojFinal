<div id="serviceEn" class="services">
    <h1>Services</h1>
    <div class="itemService">
        <div class="image">
            <img src="<?php echo e(asset("images/general/".$general->ServiceImage)); ?>" alt="<?php echo e($general->altServiceImageEn); ?>">
        </div>
        <div class="officeServices">
            <h3>What services do we provide for customers?</h3>
            <div class="totalServices">
                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="singleService">
                        <div class="iconService">
                            <img src="<?php echo e(asset("images/service/".$item->image)); ?>" alt="<?php echo e($item->altEn); ?>">
                        </div>
                        <div class="textService">
                            <h3><?php echo e($item->titleEn); ?></h3>
                            <p>
                                <?php echo e($item->textEn); ?>

                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/partials/En/serviceEn.blade.php ENDPATH**/ ?>