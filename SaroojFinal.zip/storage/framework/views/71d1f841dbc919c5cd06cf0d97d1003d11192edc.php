<div id="teamEn" class="team teamLightBg dark:teamDarkBg">
    <h1>Team  <span class="text-[black] dark:text-[#F1F1F2]">Our</span></h1>
    <div class="itemTeam">
        <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="singleTeam">
                <div class="teamPic">
                    <img src="<?php echo e(asset("images/team/".$item->image)); ?>" alt="<?php echo e($item->altEn); ?>">
                </div>
                <span class="dark:text-[#FCFCFD]"><?php echo e($item->nameEn); ?></span>
                <b><?php echo e($item->jobEn); ?></b>
                <p class="dark:text-[#D6D6D6]">
                    <?php echo e($item->textEn); ?>

                </p>
                <div class="TeamSocials">
                    <?php $__currentLoopData = $item->socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($social->link); ?>">
                            <svg class="svgLight hover:svgLightHover dark:hover:svgDarkHover" width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="<?php echo e($social->icon); ?>"/>
                            </svg>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\web design\projects\Sarooj\SaroojFinal\resources\views/FrontView/partials/En/teamEn.blade.php ENDPATH**/ ?>