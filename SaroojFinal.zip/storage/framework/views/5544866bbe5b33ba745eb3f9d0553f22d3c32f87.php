<?php $__env->startSection("contentFrontFa"); ?>
    <?php echo $__env->make("FrontView.partials.Fa.projects", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.frontFaMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\Sarooj\SaroojFinal\resources\views/FrontView/Fa/projectsFa.blade.php ENDPATH**/ ?>