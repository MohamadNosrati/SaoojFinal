<div id="service" class="services">
    <h1>خدمات ما</h1>
    <div class="itemService">
        <div class="image">
            <img src="<?php echo e(asset("images/general/".$general->ServiceImage)); ?>" alt="<?php echo e($general->altServiceImageFa); ?>">
        </div>
        <div class="officeServices">
            <h3>چه خدماتی به مشتریان عرضه می کنیم؟</h3>
            <div class="totalServices">
                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->publish===1): ?>
                        <div class="singleService">
                            <div class="iconService">
                                <img src="<?php echo e(asset("images/service/".$item->image)); ?>" alt="<?php echo e($item->altFa); ?>">
                            </div>
                            <div class="textService">
                                <h3><?php echo e($item->titleFa); ?></h3>
                                <p>
                                    <?php echo e($item->textFa); ?>

                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/partials/Fa/service.blade.php ENDPATH**/ ?>