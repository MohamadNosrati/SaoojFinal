<?php $__env->startSection("contentEn"); ?>
    <!-- ***** End Menu ***** -->
    <!-- ***** start slider ***** -->
    <?php echo $__env->make("FrontView.partials.En.sliderEn", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End slider ***** -->
    <!-- ***** start categories ***** -->
    <?php echo $__env->make("FrontView.partials.En.categoryEn", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End categories ***** -->
    <!-- ***** start services ***** -->
    <?php echo $__env->make("FrontView.partials.En.serviceEn", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End services ***** -->
    <!-- ***** start FAQ ***** -->
    <?php echo $__env->make("FrontView.partials.En.faqEn", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End FAQ ***** -->
    <!-- ***** start Team ***** -->
    <?php echo $__env->make("FrontView.partials.En.teamEn", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End Team ***** -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
    <script src="<?php echo e(asset("Front Assets/swiper/swiper-bundle.min.js")); ?>"></script>
    <script src="<?php echo e(asset("Front Assets/js/Slider.js")); ?>"></script>
    <script src="<?php echo e(asset("Front Assets/js/FAQ.js")); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.frontEnMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\Sarooj\SaroojFinal\resources\views/FrontView/En/indexEn.blade.php ENDPATH**/ ?>