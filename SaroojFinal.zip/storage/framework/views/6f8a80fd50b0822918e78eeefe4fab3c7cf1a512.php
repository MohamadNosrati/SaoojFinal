<?php $__env->startSection("titleBack","Social Create"); ?>
<?php $__env->startSection("contentBack"); ?>
    <div class="col-12 my-5">
        <h1 class="text-white text-center text-capitalize mb-3">social create</h1>
        <div class="col-8 mx-auto my-4 bg-dark py-4 px-5 rounded-4">
            <?php echo Form::open(["route"=>"social.store","method"=>"post","files"=>true]); ?>

            <?php echo Form::label("link","link",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("link",old("link"),["class"=>"form-control mb-3 text capitalize","placeholder"=>"Enter Your Link"]); ?>

            <?php $__errorArgs = ["link"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("icon","icon",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::select("icon",
[
  "M15.7548 0.541992C24.0399 0.541992 30.7557 7.25743 30.7557 15.542C30.7557 23.8266 24.0399 30.542 15.7548 30.542C7.46974 30.542 0.753906 23.8266 0.753906 15.542C0.753906 7.25743 7.46974 0.541992 15.7548 0.541992ZM20.9295 21.6561C21.2054 20.8096 22.498 12.3731 22.6578 10.7107C22.7061 10.2072 22.547 9.87264 22.2352 9.7233C21.8582 9.54199 21.2999 9.63265 20.6523 9.86612C19.764 10.1863 8.40763 15.0079 7.7515 15.287C7.12929 15.5511 6.54099 15.8394 6.54099 16.2568C6.54099 16.5503 6.71513 16.7153 7.19516 16.8868C7.69476 17.0648 8.95288 17.4463 9.69575 17.6511C10.4112 17.8487 11.2258 17.6772 11.6824 17.3935C12.1663 17.0929 17.7512 13.3559 18.1523 13.0285C18.5528 12.7011 18.8724 13.1205 18.545 13.4485C18.2176 13.7759 14.3839 17.4966 13.8784 18.0118C13.2647 18.6372 13.7003 19.2855 14.1119 19.545C14.5821 19.8411 17.9639 22.1094 18.4732 22.4733C18.9826 22.8372 19.4992 23.0022 19.972 23.0022C20.4449 23.0022 20.694 22.3794 20.9295 21.6561Z"=>"telegram",
  "M15.3779 0.541992C7.10659 0.541992 0.376953 7.27122 0.376953 15.542C0.376953 23.8128 7.10659 30.542 15.3779 30.542C23.6491 30.542 30.3788 23.8128 30.3788 15.542C30.3788 7.27122 23.6491 0.541992 15.3779 0.541992ZM11.5307 5.15738H19.2227C22.8287 5.15738 25.7631 8.09047 25.7631 11.6951V19.3866C25.7631 22.9924 22.8298 25.9266 19.225 25.9266H11.533C7.92699 25.9266 4.99262 22.9935 4.99262 19.3889V11.6973C4.99262 8.09157 7.92589 5.15738 11.5307 5.15738ZM11.5307 7.46507C9.19866 7.46507 7.30045 9.36426 7.30045 11.6973V19.3889C7.30045 21.7208 9.19976 23.6189 11.533 23.6189H19.225C21.5571 23.6189 23.4553 21.7197 23.4553 19.3866V11.6951C23.4553 9.36316 21.556 7.46507 19.2227 7.46507H11.5307ZM20.7643 9.38739C21.1889 9.38739 21.5328 9.73126 21.5328 10.1559C21.5328 10.5805 21.1889 10.9266 20.7643 10.9266C20.3397 10.9266 19.9935 10.5805 19.9935 10.1559C19.9935 9.73126 20.3397 9.38739 20.7643 9.38739ZM15.3779 9.77276C18.5592 9.77276 21.1474 12.3608 21.1474 15.542C21.1474 18.7231 18.5592 21.3112 15.3779 21.3112C12.1965 21.3112 9.60828 18.7231 9.60828 15.542C9.60828 12.3608 12.1965 9.77276 15.3779 9.77276ZM15.3779 12.0805C14.4597 12.0805 13.5792 12.4452 12.93 13.0943C12.2808 13.7435 11.9161 14.6239 11.9161 15.542C11.9161 16.46 12.2808 17.3405 12.93 17.9897C13.5792 18.6388 14.4597 19.0035 15.3779 19.0035C16.296 19.0035 17.1765 18.6388 17.8257 17.9897C18.4749 17.3405 18.8396 16.46 18.8396 15.542C18.8396 14.6239 18.4749 13.7435 17.8257 13.0943C17.1765 12.4452 16.296 12.0805 15.3779 12.0805Z"=>"instagram",
  "M15.0009 0.541992C6.71665 0.541992 0 7.25824 0 15.542C0 23.8257 6.71665 30.542 15.0009 30.542C23.2851 30.542 30.0018 23.8257 30.0018 15.542C30.0018 7.25824 23.2851 0.541992 15.0009 0.541992ZM9.37056 7.29574C10.4231 7.29574 11.1244 7.99699 11.1244 8.93199C11.1244 9.86699 10.4231 10.5682 9.2543 10.5682C8.20174 10.5695 7.50045 9.86699 7.50045 8.93199C7.50045 7.99699 8.20174 7.29574 9.37056 7.29574ZM11.2507 21.792H7.50045V11.792H11.2507V21.792ZM23.7514 21.792H20.2212V16.327C20.2212 14.8157 19.2799 14.467 18.9274 14.467C18.5749 14.467 17.3973 14.6995 17.3973 16.327C17.3973 16.5595 17.3973 21.792 17.3973 21.792H13.7508V11.792H17.3985V13.187C17.8686 12.3732 18.8099 11.792 20.575 11.792C22.3401 11.792 23.7514 13.187 23.7514 16.327V21.792Z"=>"linkin"
],
null,["class"=>"form-control mb-3"]); ?>

            <?php $__errorArgs = ["icon"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("owner","owner",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::select("team_id",$team,null,["class"=>"form-select mb-3","id"=>"owner"]); ?>

            <?php echo Form::submit("send",["class"=>"text-capitalize text-white btn btn-primary"]); ?>

            <?php echo Form::close(""); ?>

        </div>
        <?php if(session()->exists("create")): ?>
            <div class="session my-4 bg-success py-3 px-2 col-4 mx-auto rounded-3">
                <h3 class="text-center text-capitalize text-white">your record created successfully!</h3>
            </div>
        <?php endif; ?>
        <div class="text-center">
            <a class="btn btn-info text-white text-capitalize mt-3" href="<?php echo e(route("social.index")); ?>">details team</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/backView/social/create.blade.php ENDPATH**/ ?>