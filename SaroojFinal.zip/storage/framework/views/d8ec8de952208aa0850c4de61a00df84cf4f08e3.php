<?php $__env->startSection("titleBack","Bf Edit"); ?>
<?php $__env->startSection("contentBack"); ?>
    <div class="col-12 my-5">
        <h1 class="text-white text-center text-capitalize mb-3">Bf Edit</h1>
        <div class="col-8 mx-auto my-4 bg-dark py-4 px-5 rounded-4">
            <?php echo Form::model($bf,["route"=>["bf.update","id"=>$bf->id],"method"=>"put","files"=>true]); ?>

            <div class="text-center">
                <img style="width: 125px;height: 125px;border-radius: 50%;object-fit: cover" src="<?php echo e(asset("images/bf/".$bf->imageBefore)); ?>" alt="">
            </div>
            <div class="text-center">
                <img style="width: 125px;height: 125px;border-radius: 50%;object-fit: cover ;margin: 25px 0" src="<?php echo e(asset("images/bf/".$bf->imageAfter)); ?>" alt="">
            </div>
            <?php echo Form::label("imageBefore","imageBefore",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::file("imageBefore",["class"=>"form-control mb-3 text-capitalize"]); ?>

            <?php $__errorArgs = ["imageBefore"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("imageAfter","imageAfter",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::file("imageAfter",["class"=>"form-control mb-3 text-capitalize"]); ?>

            <?php $__errorArgs = ["imageAfter"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altBeforeFa","altBeforeFa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altBeforeFa",old("altBeforeFa"),["class"=>"form-control mb-3 text capitalize persian","placeholder"=>"Enter Your Persian Alt Before"]); ?>

            <?php $__errorArgs = ["altBeforeFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altBeforeEn","altBeforeEn",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altBeforeEn",old("altBeforeEn"),["class"=>"form-control mb-3 text capitalize","placeholder"=>"Enter Your English Alt Before"]); ?>

            <?php $__errorArgs = ["altBeforeEn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altAfterFa","altAfterFa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altAfterFa",old("altAfterFa"),["class"=>"form-control mb-3 persian","placeholder"=>"Enter Your Persian Alt"]); ?>

            <?php $__errorArgs = ["altAfterFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altAfterEn","altAfterEn",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altAfterEn",old("altAfterEn"),["class"=>"form-control mb-3","placeholder"=>"Enter Your English Alt"]); ?>

            <?php $__errorArgs = ["altAfterEn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("project","project",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::select("project",$project,$bf->info_id,["class"=>"form-select mb-3 text-capitalize"]); ?>

            <?php $__errorArgs = ["info_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::submit("Edit",["class"=>"text-capitalize text-white btn btn-warning"]); ?>

            <?php echo Form::close(""); ?>

        </div>
        <?php if(session()->exists("create")): ?>
            <div class="session my-4 bg-success py-3 px-2 col-4 mx-auto rounded-3">
                <h3 class="text-center text-capitalize text-white">your record created successfully!</h3>
            </div>
        <?php endif; ?>
        <div class="text-center">
            <a class="btn btn-info text-white text-capitalize mt-3" href="<?php echo e(route("bf.index")); ?>">details Bf</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/backView/bf/edit.blade.php ENDPATH**/ ?>