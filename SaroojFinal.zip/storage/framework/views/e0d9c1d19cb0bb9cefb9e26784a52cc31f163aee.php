<div class="lastProjects lpLightBg dark:lpDarkBg">
    <h1 class="dark:text-[#D6D6D6]">Last Projects</h1>
    <div class="lpItems">
        <?php $__currentLoopData = $lp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <a href="<?php echo e(route("projectInfoEn",["projectName"=>$item->PNameEn])); ?>"></a>
                <img src="<?php echo e(asset("images/project/".$item->image)); ?>" alt="<?php echo e($item->altEn); ?>">
                <div class="cover">
                    <a href="<?php echo e(route("projectInfoEn",["projectName"=>$item->PNameEn])); ?>"><?php echo e($item->PNameEn); ?></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/partials/En/lpEn.blade.php ENDPATH**/ ?>