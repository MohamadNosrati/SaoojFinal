<?php $__env->startSection("contentFrontFa"); ?>
    <!-- ***** Start Details ***** -->
    <div class="details bfLightBg dark:bfDarkBg">
    <h1 class="text-[black] dark:text-[#F1F1F2]"> پروژه <?php echo e($project->PNameFa); ?> </h1>
    <!-- ***** Start BF ***** -->
    <?php echo $__env->make("FrontView.partials.fa.bfFa", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End BF ***** -->
    <!-- ***** start projectInfo ***** --->
    <?php echo $__env->make("FrontView.partials.fa.info", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End projectInfo --->
    <!-- ***** End Details ***** -->
    <!-- ***** start video ***** -->
    <?php echo $__env->make("FrontView.partials.video", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End video ***** -->
    </div>
    <!-- ***** start Last Projects ***** -->
    <?php echo $__env->make("FrontView.partials.fa.lp", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End last Projects ***** -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
    <script src="<?php echo e(asset("Front Assets/swiper/swiper-bundle.min.js")); ?>"></script>
    <script src="<?php echo e(asset("Front Assets/js/Bf.js")); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.frontFaMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\Sarooj\SaroojFinal\resources\views/FrontView/Fa/detailsFa.blade.php ENDPATH**/ ?>