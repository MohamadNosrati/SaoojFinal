<?php $__env->startSection("titleBack","English comment Edit"); ?>
<?php $__env->startSection("contentBack"); ?>
    <div class="col-12 my-5">
        <h1 class="text-white text-center text-capitalize mb-3">English Comment Show</h1>
        <div class="col-8 mx-auto my-4 bg-dark py-4 px-5 rounded-4">
            <?php echo Form::model($comment,["route"=>["commentEn.update","id"=>$comment->id],"method"=>"put","files"=>true]); ?>

            <?php echo Form::label("publish","publish",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::select("publish",[1=>"Active",0=>"DeActive"],$comment->publish,["class"=>"form-select mb-3"]); ?>

            <?php echo Form::submit("update",["class"=>"text-capitalize text-white btn btn-warning"]); ?>

            <?php echo Form::close(""); ?>

        </div>
        <div class="text-center">
            <a class="btn btn-info text-white text-capitalize mt-3" href="<?php echo e(route("commentEn.index")); ?>">details English Comments</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/backView/commentEn/edit.blade.php ENDPATH**/ ?>