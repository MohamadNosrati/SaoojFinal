<?php $__env->startSection("titleBack","Blog Edit"); ?>
<?php $__env->startSection("contentBack"); ?>
    <div class="col-12 my-5">
        <h1 class="text-white text-center text-capitalize mb-3">Blog Edit</h1>
        <div class="text-center">
            <img style="width: 125px;height: 125px;border-radius: 50%;object-fit: cover" src="<?php echo e(asset("images/blog/".$blog->image)); ?>" alt="">
        </div>
        <div class="col-8 mx-auto my-4 bg-dark py-4 px-5 rounded-4">
            <?php echo Form::model($blog,["route"=>["blog.update","id"=>$blog->id],"method"=>"put","files"=>true]); ?>

            <?php echo Form::label("image","image",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::file("image",["class"=>"form-control mb-3 text-capitalize"]); ?>

            <?php $__errorArgs = ["image"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altFa","altFa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altFa",old("altFa"),["class"=>"form-control mb-3 text capitalize persian","placeholder"=>"Enter Your Persian Alt"]); ?>

            <?php $__errorArgs = ["altFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("altEn","altEn",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("altEn",old("altEn"),["class"=>"form-control mb-3","placeholder"=>"Enter Your English Alt"]); ?>

            <?php $__errorArgs = ["altEn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("textFa","textFa",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::textarea("textFa",old("textFa"),["class"=>"form-control mb-3 persian","placeholder"=>"Enter Your Persian Text"]); ?>

            <?php $__errorArgs = ["textFa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("textEn","textEn",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::textarea("textEn",old("textEn"),["class"=>"form-control mb-3","placeholder"=>"Enter Your English Text"]); ?>

            <?php $__errorArgs = ["textEn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::submit("edit",["class"=>"text-capitalize text-white btn btn-warning"]); ?>

            <?php echo Form::close(""); ?>

        </div>
        <div class="text-center">
            <a class="btn btn-info text-white text-capitalize mt-3" href="<?php echo e(route("blog.index")); ?>">details blog</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/backView/blog/edit.blade.php ENDPATH**/ ?>