<?php if(!empty($project->info) and !empty($project->info->video)): ?>
<div class="videoProject bg-[#1D1D1D]">
    <div id="<?php echo e($project->info->video_id); ?>"><script type="text/JavaScript" src="<?php echo e($project->info->video); ?>"></script></div>
</div>
<?php endif; ?>
<?php /**PATH D:\web design\projects\Sarooj\SaroojFinal\resources\views/FrontView/partials/video.blade.php ENDPATH**/ ?>