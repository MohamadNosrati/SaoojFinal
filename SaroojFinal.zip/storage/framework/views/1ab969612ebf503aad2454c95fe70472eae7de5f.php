<?php $__env->startSection("contentFrontFa"); ?>
    <!-- ***** End Menu ***** -->
    <!-- ***** start slider ***** -->
    <?php echo $__env->make("FrontView.partials.Fa.slider", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End slider ***** -->
    <!-- ***** start categories ***** -->
    <?php echo $__env->make("FrontView.partials.Fa.category", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End categories ***** -->
    <!-- ***** start services ***** -->
    <?php echo $__env->make("FrontView.partials.Fa.service", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End services ***** -->
    <!-- ***** start FAQ ***** -->
    <?php echo $__env->make("FrontView.partials.Fa.faq", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End FAQ ***** -->
    <!-- ***** start Team ***** -->
    <!--     dark:linearCatDark-->
    <?php echo $__env->make("FrontView.partials.Fa.team", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ***** End Team ***** -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
    <script src="<?php echo e(asset("Front Assets/swiper/swiper-bundle.min.js")); ?>"></script>
    <script src="<?php echo e(asset("Front Assets/js/Slider.js")); ?>"></script>
    <script src="<?php echo e(asset("Front Assets/js/FAQ.js")); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.frontFaMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/FrontView/Fa/index.blade.php ENDPATH**/ ?>