<?php $__env->startSection("titleBack","Seo Edit"); ?>
<?php $__env->startSection("contentBack"); ?>
    <div class="col-12 my-5">
        <h1 class="text-white text-center text-capitalize mb-3">Seo Edit</h1>
        <div class="col-8 mx-auto my-4 bg-dark py-4 px-5 rounded-4">
            <?php echo Form::model($seo,["route"=>["seo.update","id"=>$seo->id],"method"=>"put","files"=>true]); ?>

            <?php echo Form::label("page","page",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::select("page",[
    "Home Persian"=>"Home Persian",
    "Home English"=>"Home English",
    "Projects Persian"=>"Projects Persian",
    "Projects English"=>"Projects English",
    "Project Details Persian"=>"Project Details Persian",
    "Project Details English"=>"Project Details English",
    "About Persian"=>"About Persian",
    "About English"=>"About English"
],$seo->id,["class"=>"form-select mb-3"]); ?>

            <?php echo Form::label("title","title",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("title",old("title"),["class"=>"form-control mb-3 text capitalize","placeholder"=>"Enter Your Title"]); ?>

            <?php $__errorArgs = ["title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("description","description",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("description",old("description"),["class"=>"form-control mb-3 text capitalize","placeholder"=>"Enter Your Description"]); ?>

            <?php $__errorArgs = ["description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("author","author",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::text("author",old("author"),["class"=>"form-control mb-3 text capitalize","placeholder"=>"Enter Your Author"]); ?>

            <?php $__errorArgs = ["author"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::label("keywords","keywords",["class"=>"text-white text-capitalize mb-2"]); ?>

            <?php echo Form::textarea("keywords",old("keywords"),["class"=>"form-control mb-3 text capitalize","placeholder"=>"Enter Your Key Words"]); ?>

            <?php $__errorArgs = ["keywords"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger my-3 text-capitalize"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::submit("Edit",["class"=>"text-capitalize text-white btn btn-warning"]); ?>

            <?php echo Form::close(""); ?>

        </div>
        <?php if(session()->exists("create")): ?>
            <div class="session my-4 bg-success py-3 px-2 col-4 mx-auto rounded-3">
                <h3 class="text-center text-capitalize text-white">your record created successfully!</h3>
            </div>
        <?php endif; ?>
        <div class="text-center">
            <a class="btn btn-info text-white text-capitalize mt-3" href="<?php echo e(route("seo.index")); ?>">details Seo</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web design\projects\SaroojFinal\resources\views/backView/seo/edit.blade.php ENDPATH**/ ?>