<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>
        <?php echo $__env->yieldContent("titleBack"); ?>
    </title>
    <link rel = "icon" href ="<?php echo e(asset("Front Assets/Icons/Logo/logo.svg")); ?>" type = "image/x-icon">

    <link rel="stylesheet" href="<?php echo e(asset("build/assets/app-09b264ce.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("build/assets/app-75b2c64a.css")); ?>">


    <?php echo $__env->yieldContent("css"); ?>
</head>
<body class="bg-black">
<div class="menu">
    <nav class="">
        <ul class="">
            <li class=""><a target="_blank" class= "text-capitalize text-decoration-none" href="<?php echo e(route("home.index")); ?>">Persian Website</a></li>
            <li class=""><a target="_blank" class= "text-capitalize text-decoration-none" href="<?php echo e(route("homeEn.index")); ?>">English Website</a></li>
            <li class=""><a class= "text-capitalize text-decoration-none" href="<?php echo e(route("panel.index")); ?>">admin panel</a></li>
            <li>
                <?php echo Form::open(["route"=>"logout","method"=>"POST","files"=>true]); ?>

                <?php echo Form::submit("LogOut",["class"=>"btn text-danger"]); ?>

                <?php echo Form::close(); ?>

            </li>
        </ul>
    </nav>
</div>
<?php echo $__env->yieldContent("contentBack"); ?>


<script type="module" src="<?php echo e(asset("build/assets/app-e25bc80d.js")); ?>"></script>
<?php echo $__env->yieldContent("js"); ?>
</body>
</html>
<?php /**PATH D:\web design\projects\SaroojFinal\resources\views/layouts/backMaster.blade.php ENDPATH**/ ?>